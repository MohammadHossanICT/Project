# REST-API-how-to-fetch-data-from-the-server
How to fetch data from the server and present it in a tableview.

If you want to see how I built this from scratch, you can check my YouTube channel Swift Code Snippets: https://www.youtube.com/channel/UCENwGAGUfEL1-MWAQt7-Acg/featured
