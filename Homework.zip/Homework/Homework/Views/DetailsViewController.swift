//
//  DetailsViewController.swift
//  Homework
//
//  Created by test on 04/02/2022.
//

import Foundation
import UIKit



class  DetailsViewController : UIViewController{
    
    @IBOutlet private weak var tableView: UITableView!
    
    var changeStatus: ((Bool, String) -> Void)?
    var identifier = ""
    
    private let switchControl: UISwitch = {
        let switchControl = UISwitch()
        switchControl.translatesAutoresizingMaskIntoConstraints = false
        switchControl.isOn = false
        return switchControl
    }()

    @IBOutlet weak var customSwitch: UISwitch!
    
        override func viewDidLoad() {
            super.viewDidLoad()
            // Do any additional setup after loading the view, typically from a nib.
            view.addSubview(switchControl)
            
            switchControl.addTarget(self, action: #selector(changeSwitchControl), for: .valueChanged)
            
            let safeArea = view.safeAreaLayoutGuide
            switchControl.topAnchor.constraint(equalTo: safeArea.topAnchor).isActive = true
            switchControl.leadingAnchor.constraint(equalTo: safeArea.leadingAnchor).isActive = true
            
            setUpUI()

        }
    
    @objc
    private func changeSwitchControl() {
        changeStatus?(switchControl.isOn, identifier)
    }
      
    
    
        private func setUpUI() {
        view.backgroundColor = .white
    }
    
}



 
/*  @IBAction func switchDidChange(_ sender : UISwitch)
  {
      if  sender.isOn{
          view.backgroundColor = .red
      }
      else {
          view.backgroundColor = .blue
      }
  }*/
