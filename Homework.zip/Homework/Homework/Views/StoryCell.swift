//
//  StoryCell.swift
//  Homework
//
//  Created by test on 04/02/2022.
//

import UIKit

class StoryCell: UITableViewCell {
    
    static let identifier = "StoryCell"
    
    private lazy var storyIdLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.textAlignment = .left
        return label
    }()
    
    public lazy var storyTitleLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.textAlignment = .left
        return label
    }()
    
    
   
    
    private lazy var statusStory: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.textAlignment = .left
        return label
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setUpUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func configureCell(Id: Int,title: String,statusString: String) {
        
        storyIdLabel.text = "Id: \(String(Id))"
        
        storyTitleLabel.text = "Status :\(title)"
        statusStory.text = "Status:\(statusString)"
        
        
    }
    
   /* func configureCell(Id: Int) {
        storyIdLabel.text = "Id: \(String(Id))"
       
    }*/
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    private func setUpUI() {
        contentView.addSubview(storyTitleLabel)
        
        // constraints
        let safeArea = contentView.safeAreaLayoutGuide
        storyTitleLabel.topAnchor.constraint(equalTo: safeArea.topAnchor).isActive = true
        storyTitleLabel.leadingAnchor.constraint(equalTo: safeArea.leadingAnchor).isActive = true
        storyTitleLabel.trailingAnchor.constraint(equalTo: safeArea.trailingAnchor).isActive = true
        
        contentView.addSubview(storyIdLabel)
        let safeArea1 = contentView.safeAreaLayoutGuide
        storyIdLabel.topAnchor.constraint(equalTo: storyTitleLabel.topAnchor).constant = 5
        storyIdLabel.bottomAnchor.constraint(equalTo: safeArea1.bottomAnchor).isActive = true
        storyIdLabel.leadingAnchor.constraint(equalTo: safeArea1.leadingAnchor).isActive = true
        storyIdLabel.trailingAnchor.constraint(equalTo: safeArea1.trailingAnchor).isActive = true
        
       /* contentView.addSubview(statusStory)
        let safeArea2 = contentView.safeAreaLayoutGuide
        statusStory.topAnchor.constraint(equalTo: statusStory.topAnchor).isActive = true
        statusStory.bottomAnchor.constraint(equalTo: safeArea2.bottomAnchor).isActive = true
        statusStory.leadingAnchor.constraint(equalTo: safeArea2.leadingAnchor).isActive = true
        statusStory.trailingAnchor.constraint(equalTo: safeArea2.trailingAnchor).isActive = true*/
        
        
    }

}
