//
//  ViewController.swift
//  Homework
//
//  Created by test on 04/02/2022.
//

import UIKit
import Combine
import Foundation

class ViewController: UIViewController {
    
    // ! Mark is means it not null the value will in story board
    
    // use lazy property to tell compiler instance value  of the datasource self class and execuate the controller code to set the value of tableview datasource
    
    private let viewModel = ViewModel()
    private var subcriber  = Set<AnyCancellable>()
    
    private var storiesTrue = [String]()
    @Published private(set) var stories = [Rover]()
    private var datasourceStories = [Rover]()
    
   private lazy var tableView: UITableView = {
       
       let tableview = UITableView()
       tableview.translatesAutoresizingMaskIntoConstraints = false// adding constrains
       tableview.dataSource = self
       tableview.showsVerticalScrollIndicator = false
       tableview.register(StoryCell.self, forCellReuseIdentifier: StoryCell.identifier)
        return tableview
   }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpUI()
        setUpBinding()
        tableView.dataSource = self
        tableView.delegate = self
        self.tableView.rowHeight = 44;
        
        
        // display the second view controller using push methods 
        /*let detail = DetailsViewController()
        detail.name "Mohammad"
        navigationController?.pushViewController(detail, animated: true)*/
    }
    
    private func setUpUI() {
        view.backgroundColor = .white
        view.addSubview(tableView)// adding hierracy key like adding into story board
        
        // creating constrains with safe area
        
        let safeArea = view.safeAreaLayoutGuide
        tableView.topAnchor.constraint(equalTo: safeArea.topAnchor).isActive = true
        tableView.leadingAnchor.constraint(equalTo: safeArea.leadingAnchor).isActive = true
        tableView.trailingAnchor.constraint(equalTo: safeArea.trailingAnchor).isActive = true
        tableView.bottomAnchor.constraint(equalTo: safeArea.bottomAnchor).isActive = true
        
        
    }
    
    private func setUpBinding(){
        
        viewModel
            .$rovers
            .receive(on : RunLoop.main)
            .sink {[weak self]_ in
                self?.tableView.reloadData()
            }
            .store(in: &subcriber)
        viewModel.getStories()
    }
    
    private func getStatus(by identifier: String) -> Bool {
        return storiesTrue.contains(identifier)
    }
}

extension ViewController: UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.rovers.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: StoryCell.identifier , for: indexPath) as? StoryCell
        else{ return UITableViewCell()}
        
        let row = indexPath.row
        
        
        let Id = viewModel.getId(by: row)
        let title = viewModel.getTitle(by: row)
        let identifier = viewModel.getIdentifier(by: indexPath.row)
        let status = getStatus(by: identifier) ? "active" : "false"
                
        cell.configureCell(Id: Id,title: title,statusString: status)
        return cell
    }
    

   
}

extension ViewController: UITableViewDataSourcePrefetching {
    
    func tableView(_ tableView: UITableView, prefetchRowsAt indexPaths: [IndexPath]) {
        viewModel.getStories()
    }
    
}

extension ViewController : UITableViewDelegate{
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
     {
        let second  = DetailsViewController()
        navigationController?.pushViewController(second, animated: true)
         
         /*
          HERE IS WHERE YOU CAN SETUP THE CLOSURE
          */
         
         second.changeStatus = { status, identifier in
             print(status)
             print(identifier)
         }
        
     }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 44;
    }
}
