//
//  ViewModel.swift
//  Homework
//
//  Created by test on 04/02/2022.
//
// ADDING business logic
import Foundation


class ViewModel {
    
  private   let networkManager  = NetworkManager()
    
   @Published private (set) var rovers  = [Rover]()
    
    func getStories (){
        networkManager
            .getModel(Post.self, from: NetworkURLs.baseURL) {[weak self] result in
                
                switch result{
        
                case .success(let response):
                    self?.rovers = response.photos.map{$0.rover}
                case .failure( let error):
                    print( error.localizedDescription)
                }
            }
        
    }
    
    func getTitle(by row: Int) -> String {
        let story = rovers[row]
        return story.status
    }
    
    func getId(by row: Int) -> Int {
        let story = rovers[row]
        return story.id
    }
    func getIdentifier(by row: Int) -> String {
        return "\(rovers[row].status)"
    }
    
    
    
    
}

