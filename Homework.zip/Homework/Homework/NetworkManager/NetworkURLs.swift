//
//  NetworkURLs.swift
//  RedditChallenge
//
//  Created by Christian Quicano on 2/4/22.
//

import Foundation

enum NetworkURLs {
    static let baseURL = "https://api.nasa.gov/mars-photos/api/v1/rovers/curiosity/photos?sol=1000&api_key=DEMO_KEY"
}
