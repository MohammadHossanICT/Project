//
//  NetworkManager.swift
//  Challenge
//
//  Created by Christian Quicano on 1/27/22.
//

import Foundation

enum NetworkError: Error {
    case badURL
    case other(Error)
}

class NetworkManager {
    
    func getStories(from url: String, completion: @escaping (Result<Story, NetworkError>) -> Void) {
        
        guard let url = URL(string: url) else {
            completion(.failure(.badURL))
            return
        }
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                completion(.failure(.other(error)))
                return
            }
            if let data = data {
                do {
                    let response = try JSONDecoder().decode(Story.self, from: data)
                    completion(.success(response))
                } catch let error {
                    completion(.failure(.other(error)))
                }
            }
        }
        .resume()
        
    }
    
    func getImageData(from url: String, completion: @escaping (Result<Data, NetworkError>) -> Void) {
        
    }
    
}
