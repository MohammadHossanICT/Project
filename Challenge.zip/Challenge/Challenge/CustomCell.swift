//
//  CustomCell.swift
//  Challenge
//
//  Created by Christian Quicano on 1/27/22.
//

import UIKit

class CustomCell: UITableViewCell {
    
    @IBOutlet private weak var titleLabel: UILabel!
    @IBOutlet private weak var logoImage: UIImageView!
    @IBOutlet private weak var switchControl: UISwitch!
    
    func configureCell(title: String?, imageData: Data?, isFav: Bool) {
        titleLabel.text = title
        logoImage.image = nil
        if let data = imageData {
            logoImage.image = UIImage(data: data)
        }
        switchControl.isOn = isFav
    }
}
