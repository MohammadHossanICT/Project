//
//  ViewController.swift
//  Challenge
//
//  Created by Christian Quicano on 1/27/22.
//

import UIKit

class ViewController: UIViewController {
    
    private let networkManger = NetworkManager()

    @IBOutlet private weak var tableView: UITableView!
    private var items = [Story]()
    private var cache = [String: Data]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    private func setUpView() {
        tableView.dataSource = self
        tableView.delegate = self
    }
    
    private func fetchData() {
        networkManger.getStories(from: NetworkURLs.storiesURL) { [weak self] result in
            switch result {
            case .success(let response):
                self?.items = [response]
                
                // update our view
                DispatchQueue.main.async {
                    self?.tableView.reloadData()
                }
                
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
    
    private func getData(with key: String, at row: Int) -> Data? {
        if let data = cache[key] {
            return data
        }
        // download the image
        networkManger.getImageData(from: key) { [weak self] result in
            switch result {
            case .success(let data):
                self?.cache[key] = data
                // update our view
                DispatchQueue.main.async {
                    self?.tableView.reloadRows(at: [IndexPath(row: row, section: 0)], with: .automatic)
                }
                
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
        return nil
    }
    
}

extension ViewController: UITableViewDelegate {
    
}

extension ViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as? CustomCell
        else { return UITableViewCell() }
        
        let story = items[indexPath.row]
        let key = story.path
        let data = getData(with: key, at: indexPath.row)
        cell.configureCell(title: "Title", imageData: data, isFav: true)
        return cell
    }
    
}
