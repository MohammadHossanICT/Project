//
//  Story.swift
//  Challenge
//
//  Created by Christian Quicano on 1/27/22.
//

import Foundation

struct Story: Decodable {
    let id: Int
    let path: String
    let isFav: Bool
}
