//
//  NetworkURLs.swift
//  Challenge
//
//  Created by Christian Quicano on 1/27/22.
//

import Foundation

enum NetworkURLs {
    static let baseURL = ""
    static let storiesURL = "\(baseURL)"
}
