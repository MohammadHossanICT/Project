//
//  ViewModelCombine.swift
//  MVVM
//
//  Created by Mohammed Al-Quraini on 2/2/22.
//

import Foundation
import Combine
import UIKit

class ViewModelCombine {
    
    private let networkManager = NetworkManagerCombine()
    private var cancellers = Set<AnyCancellable>()
    
    @Published var image = UIImage()
    
    func getImage() {
        networkManager
            .getImage(from: NetworkUrls.url)
            .sink(receiveCompletion: { _ in },
                  receiveValue: { [weak self] image in
                self?.image = image
            })
            .store(in: &cancellers)
    }

}
