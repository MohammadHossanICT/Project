//
//  ViewController.swift
//  load image
//
//  Created by Mohammed Al-Quraini on 2/7/22.
//

import UIKit
import Combine

class ViewController: UIViewController {
    
    private let viewModelCombine = ViewModelCombine()
    private var subscribers = Set<AnyCancellable>()
    
    private let imageView :UIImageView = {
        let image = UIImageView()
        image.translatesAutoresizingMaskIntoConstraints = false
        image.backgroundColor = .systemBlue
        image.contentMode = .scaleAspectFill
        return image
    }()
    
    private let button : UIButton = {
       let button = UIButton()
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitle("LOAD IMAGE", for: .normal)
        button.setTitleColor(.systemBlue, for: .normal)
        
        return button
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        view.backgroundColor = .white
        
        // subviews
        view.addSubview(imageView)
        view.addSubview(button)
        
        // set bindings
        setUpBinding()
        
        // add target
        button.addTarget(self, action: #selector(loadImage), for: .touchUpInside)
        
        
    }
    
    // subviews
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        let safeArea = view.safeAreaLayoutGuide
        
        // image constraints
        imageView.topAnchor.constraint(equalTo: safeArea.topAnchor).isActive = true
        imageView.leadingAnchor.constraint(equalTo: safeArea.leadingAnchor).isActive = true
        imageView.trailingAnchor.constraint(equalTo: safeArea.trailingAnchor).isActive = true
        imageView.bottomAnchor.constraint(equalTo: button.topAnchor, constant: -10).isActive = true
        
        // button constraints
        button.bottomAnchor.constraint(equalTo: safeArea.bottomAnchor).isActive = true
        button.centerXAnchor.constraint(equalTo: safeArea.centerXAnchor).isActive = true
        
    }
    
    // set bindings
    private func setUpBinding() {
        viewModelCombine
            .$image
            .receive(on: RunLoop.main)
            .sink(receiveValue: {[weak self] image in
                DispatchQueue.main.async {
                    self?.imageView.image = image
                }

            })
            .store(in: &subscribers)
        
        viewModelCombine.getImage()
    }
    
    // load image function
    @objc private func loadImage(){
        viewModelCombine.getImage()
    }


}

