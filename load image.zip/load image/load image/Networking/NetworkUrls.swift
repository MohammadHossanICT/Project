//
//  NetworkUrls.swift
//  load image
//
//  Created by Mohammed Al-Quraini on 2/7/22.
//

import Foundation

enum NetworkUrls {
    static let url = "https://picsum.photos/500/500"
}
