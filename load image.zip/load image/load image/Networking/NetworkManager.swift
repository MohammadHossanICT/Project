//
//  NetworkManager.swift
//  load image
//
//  Created by Mohammed Al-Quraini on 2/7/22.
//

import Foundation
import Combine
import UIKit

class NetworkManagerCombine {
    
    func getImage(from url: String) -> AnyPublisher<UIImage, Error> {
        
        guard let url = URL(string: url) else {
            fatalError()
        }
        
        return URLSession.shared.dataTaskPublisher(for: url)
            .compactMap { UIImage(data: $0.data) }
            .mapError { $0 as Error }
            .eraseToAnyPublisher()
        
    }
    
}
