//  NasaCell.swift
//  firstApiNasaProject
//
//  Created by Jasim Uddin on 04/02/2022.
//

import UIKit

class NasaCell: UITableViewCell {
        
    static let identifier = "NasaCell"
    
    private lazy var storyImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
        
    private lazy var idLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.textAlignment = .left
        label.numberOfLines = 0
        label.textColor = UIColor.black
        return label
        }()
    
    private lazy var statusLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.textAlignment = .left
        label.numberOfLines = 0
        label.textColor = UIColor.orange
        return label
        }()
   

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
            super.init(style: style, reuseIdentifier: reuseIdentifier)
            setUPUI()
        }
        
    required init?(coder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    func configureCell(id: Int){
        idLabel.text = "ID: \(id)"
        }
    func configureCell(status: Bool){
        statusLabel.text = "Status: \(status)"
    }
    func configureCell(imageData: Data?) {
        if let imageData = imageData {
            let  image = UIImage(data: imageData)
            storyImageView.image = image
            
        }
    }
    
    private func setUPUI(){
           
            contentView.addSubview(idLabel)

            contentView.addSubview(statusLabel)

            //creating constraints for the label
            let safeArea = contentView.safeAreaLayoutGuide
            idLabel.topAnchor.constraint(equalTo: safeArea.topAnchor, constant: 10).isActive = true
            idLabel.trailingAnchor.constraint(equalTo: safeArea.trailingAnchor, constant: 20).isActive = true
            idLabel.leadingAnchor.constraint(equalTo: safeArea.leadingAnchor, constant: 20).isActive = true
        
            statusLabel.topAnchor.constraint(equalTo: idLabel.bottomAnchor).isActive = true
            statusLabel.trailingAnchor.constraint(equalTo: safeArea.trailingAnchor, constant: 20).isActive = true
            statusLabel.leadingAnchor.constraint(equalTo: safeArea.leadingAnchor, constant: 20).isActive = true
            statusLabel.bottomAnchor.constraint(equalTo: safeArea.bottomAnchor, constant: -10).isActive = true
        }

    }

