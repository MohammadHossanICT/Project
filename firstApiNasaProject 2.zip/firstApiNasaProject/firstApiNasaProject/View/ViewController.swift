//  ViewController.swift
//  firstApiNasaProject
//
//  Created by Jasim Uddin on 02/02/2022.
//
import UIKit
import Combine

class ViewController: UIViewController {
    
    private let viewModel = ViewModel()
    private var subscribers = Set<AnyCancellable>()
    private var photoResponse = [PhotoData]()
    private var rowSelected: Int = 0
    private var picUrlViewController: String = ""
    private var userDefault = UserDefaults.standard
    
    private lazy var tableView: UITableView = {
        let tableView = UITableView(frame: .zero)
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(NasaCell.self, forCellReuseIdentifier: NasaCell.identifier)
        tableView.showsVerticalScrollIndicator = false
        return tableView
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        setUpUI()
        setUpBinding()
    }
    //to keep the same state as viewdidLoad
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        setUpUI()
        setUpBinding()
        
    }
    
    private func setUpUI() {
        title = "Main screen"
        view.backgroundColor = UIColor.white
        //Create TableView
        
        view.addSubview(tableView)
        
        //Add constraints
        let safeArea = view.safeAreaLayoutGuide
        tableView.topAnchor.constraint(equalTo: safeArea.topAnchor).isActive = true
        tableView.bottomAnchor.constraint(equalTo: safeArea.bottomAnchor).isActive = true
        tableView.trailingAnchor.constraint(equalTo: safeArea.trailingAnchor).isActive = true
        tableView.leadingAnchor.constraint(equalTo: safeArea.leadingAnchor).isActive = true
    }


private func setUpBinding() {
    viewModel
        .$stories
        .receive(on: RunLoop.main)
        .sink { [weak self]_ in
            self?.photoResponse = self?.viewModel.stories ?? []
            self?.tableView.reloadData()
            
        }
        .store(in: &subscribers)
        
    viewModel.getData()
   }
}
extension ViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.stories.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: NasaCell.identifier, for: indexPath) as? NasaCell
        else { return UITableViewCell()}
        
        let row = indexPath.row
        let id = viewModel.getId(by: row)
        picUrlViewController =  viewModel.getImageUrl(by: row)
        cell.configureCell(id: id)
        cell.configureCell(status: userDefault.bool(forKey: "SwitchStateForRow\(row)"))
       
        return cell
    }
}

extension ViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("tap in the cell")
        let second = DetailViewController()
        navigationController?.pushViewController(second, animated: true)
        rowSelected = indexPath.row
        print("didSelectRowAt \(rowSelected)")
        second.rowSelected = rowSelected
        second.picUrl = photoResponse[rowSelected].imgSrc
        print("didSelectRowAt \(second.picUrl)")
    }
    
}
