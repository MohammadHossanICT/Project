//
//  DetailViewController.swift
//  firstApiNasaProject
//
//  Created by Christian Quicano on 2/7/22.
//

import UIKit

class DetailViewController: UIViewController {
    private let viewModel = ViewModel()
    private var userDefault = UserDefaults.standard
    var changeStatus: ((Bool, String) -> Void)?
    var id = 0
    var rowSelected: Int = 0
    var picUrl: String = ""
    
    
    private lazy var tableView: UITableView = {
        let tableView = UITableView(frame: .zero)
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.register(NasaCell.self, forCellReuseIdentifier: NasaCell.identifier)
        tableView.showsVerticalScrollIndicator = false
        tableView.showsVerticalScrollIndicator = false
        return tableView
    }()
    
    private let switchControl: UISwitch = {
        let switchControl = UISwitch()
        switchControl.translatesAutoresizingMaskIntoConstraints = false
        switchControl.isOn = false
        return switchControl
    }()

    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpUI()
        
        switchControl.isOn = userDefault.bool(forKey: "SwitchStateForRow\(rowSelected)")
    }
    
    private func setUpUI() {
        view.backgroundColor = .white
        view.addSubview(switchControl)
        view.addSubview(imgSrc)
        
        switchControl.addTarget(self, action: #selector(changeSwitchControl), for: .valueChanged)
        
        let safeArea = view.safeAreaLayoutGuide
        switchControl.topAnchor.constraint(equalTo: safeArea.topAnchor).isActive = true
        switchControl.leadingAnchor.constraint(equalTo: safeArea.leadingAnchor, constant: 20).isActive = true
        switchControl.trailingAnchor.constraint(equalTo: safeArea.trailingAnchor).isActive = true
        
        imgSrc.topAnchor.constraint(equalTo: switchControl.bottomAnchor).isActive =  true
        imgSrc.leadingAnchor.constraint(equalTo: safeArea.leadingAnchor).isActive = true
        imgSrc.trailingAnchor.constraint(equalTo: safeArea.trailingAnchor).isActive = true
        imgSrc.bottomAnchor.constraint(equalTo: safeArea.bottomAnchor).isActive = true
    }
    
    @objc
    private func changeSwitchControl() {
        if switchControl.isOn {
            userDefault.set(true, forKey: "SwitchStateForRow\(rowSelected)")
        }else{
            userDefault.set(false, forKey: "SwitchStateForRow\(rowSelected)")
        }
        
    }
    
   
    
    private lazy var imgSrc: UIImageView = {
        let imgSrc = UIImageView()
        imgSrc.translatesAutoresizingMaskIntoConstraints = false
        imgSrc.contentMode = .scaleAspectFit
        imgSrc.backgroundColor = .lightGray
        return imgSrc
    }()

    private func getImageUrl(){
        print(picUrl)

        guard let imageUrl:URL = URL(string: picUrl) else {
            return
        }
        imgSrc.loadImage(withUrl: imageUrl)
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        getImageUrl()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        setUpUI()
    }
}
/**Load  the image using url**/
extension UIImageView {
    func loadImage(withUrl url: URL) {
           DispatchQueue.global().async { [weak self] in
               if let imageData = try? Data(contentsOf: url) {
                   if let imgSrc = UIImage(data: imageData) {
                       DispatchQueue.main.async {
                           self?.image = imgSrc
                       }
                   }
               }
           }
       }
}

    

