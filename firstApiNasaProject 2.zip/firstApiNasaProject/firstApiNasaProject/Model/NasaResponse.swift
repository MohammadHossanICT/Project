//
//  NasaResponse.swift
//  firstApiNasaProject
//
//  Created by Jasim Uddin on 04/02/2022.
//

import Foundation

struct NasaResponse: Codable {
    let photos: [PhotoData]
}

struct PhotoData: Codable {
    let id, sol: Int
    let camera: CameraData
    let imgSrc: String
    let earthDate: String
    let rover: RoverData

enum CodingKeys: String, CodingKey {
    case id, sol
    case imgSrc = "img_src"
    case earthDate = "earth_date"
    case rover, camera
    }
}

struct RoverData: Codable {
    let name: String
    let status: String
    

}
struct CameraData: Codable {
    let roverID: Int
    
    enum CodingKeys: String, CodingKey {
        case roverID = "rover_id"
    }
}
