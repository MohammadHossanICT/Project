//
//  NetworkManager.swift
//  nasaApi
//
//  Created by Jasim Uddin on 31/01/2022.
//

import Foundation



class NetworkManager {
    
    func getData(from url: String, completion: @escaping (Result<NasaResponse, NetworkError>) ->()) {
        
        guard let url = URL(string: url) else {
            completion(Result.failure(NetworkError.badURL))
            return
        }
        
        let session = URLSession.shared
        session.dataTask(with: url, completionHandler: { data, response, error in
            
            if let data = data {
                do {
                    let response: NasaResponse = try JSONDecoder().decode(NasaResponse.self, from: data)
                    completion(.success(response))
                }catch let error {
                    let error = error
                    print(error)
                    completion(.failure(.other(error)))
                }
            }
            if let error = error {
                completion(Result.failure(NetworkError.other(error)))
            }
        })
            .resume()
    
    }
    func getId(from url: String, completion: @escaping (Result<NasaResponse, NetworkError>) ->()) {
        
        guard let url = URL(string: url) else {
            completion(Result.failure(NetworkError.badURL))
            return
        }
        
        let session = URLSession.shared
        session.dataTask(with: url, completionHandler: { data, response, error in
            
            if let data = data {
                do {
                    let response = try JSONDecoder().decode(NasaResponse.self, from: data)
                    completion(.success(response))
                }catch let error {
                    let error = error
                    print(error)
                    completion(.failure(.other(error)))
                }
            }
            if let error = error {
                completion(Result.failure(NetworkError.other(error)))
            }
        })
            .resume()
    
    }
    func getImageData(from url: String, completion: @escaping (Data?) -> Void) {
        guard let url = URL(string: url) else {
            completion (nil)
            return
        }
        URLSession.shared.dataTask(with: url) { data, response, error in
            completion(data)
            
        }
        .resume()
    }
    
 }

