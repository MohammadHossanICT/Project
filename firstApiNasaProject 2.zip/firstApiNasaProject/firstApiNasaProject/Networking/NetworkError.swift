//
//  NetworkError.swift
//  nasaApi
//
//  Created by Jasim Uddin on 31/01/2022.
//

import Foundation

enum NetworkError: Error, LocalizedError {
    case badURL
    case other(Error)

var errorDescription: String? {
    switch self {
    case .badURL:
        return "Bad URL"
        
    case .other(let error):
        return error.localizedDescription
    }
 }
}
