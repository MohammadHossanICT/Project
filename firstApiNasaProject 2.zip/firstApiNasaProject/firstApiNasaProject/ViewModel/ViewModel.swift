//
//  ViewModel.swift
//  firstApiNasaProject
//
//  Created by Jasim Uddin on 04/02/2022.
//

import Foundation
import Combine

class ViewModel {
    private let networkManager = NetworkManager()
    
    private var imgSrc = ""
    
    @Published private(set) var stories = [PhotoData]()
    
    func getData() {
        networkManager
            .getData(from: NetworkURLs.baseURL) { [weak self] result in
                switch result {
                case .success(let response):
                    self?.stories = response.photos.map { $0.self }
                    print(self?.stories.count ?? 0)
                case .failure(let error):
                    print(error.localizedDescription)
                }
            }
    }
    
    func getStatus(by row: Int) -> String {
        let story = stories[row]
        return story.rover.status.capitalized
    }
    
        func getId(by row: Int) -> Int {
            let story = stories[row]
            return story.id
        }
    
    func getImageUrl(by row: Int) -> String {
        return stories[row].imgSrc
    }
    
}
