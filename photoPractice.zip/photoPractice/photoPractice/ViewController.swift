//
//  ViewController.swift
//  photoPractice
//
//  Created by Consultant on 2/7/22.
//

import UIKit

class ViewController: UIViewController {
    // set up image view
    private let imageView: UIImageView =
    {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFill
        imageView.backgroundColor = .white
        return imageView
    }()
    //set up button
    private let button: UIButton = {
        let button = UIButton()
        button.setTitle("Get New Photo", for: .normal)
        button.setTitleColor(.black, for: .normal)
        return button
    }()
    // load data to screen
    override func viewDidLoad() {
        super.viewDidLoad()
        // add image to screen w/ dimentions
        view.addSubview(imageView)
        imageView.frame = CGRect(x: 0, y: 0, width: 300, height: 300)
        imageView.center = view.center
        // add button to screen
        view.addSubview(button)
        // Do any additional setup after loading the view.
        getPhoto()
        //button tap
        button.addTarget(self, action: #selector(buttonTap), for: .touchUpInside)
    }
    // set up layout
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        button.frame = CGRect(x: 20, y: view.frame.size.height - 50 - view.safeAreaInsets.bottom, width: view.frame.size.width - 40, height: 50)
    }
    
    // button tap
    @objc func buttonTap() {
        getPhoto()
    }
    
    // get photo from url
    func getPhoto()
    {
        let urlString = "https://picsum.photos/500/500"
        let url = URL(string: urlString)!
        guard let data = try? Data(contentsOf: url) else {
            return
        }
        imageView.image = UIImage(data: data)
    }


}

