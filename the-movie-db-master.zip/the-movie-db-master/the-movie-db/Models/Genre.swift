//
//  Genre.swift
//  iOS-challenge-BTG
//
//  Created by Bruno on 20/01/20.
//  Copyright © 2020 Bruno. All rights reserved.
//

import Foundation

struct Genre: Codable {
    var id: Int = 0
    var name: String = ""
}
