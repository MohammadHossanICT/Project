# The Movie DB
A simple project created using Swift to show the use of Core Data and a REST Api in an iOS application.

Openning the app you'll see a list of most recent movies. If you touch on favorite movie button, the movie information is stored in Core Data to be consulted later in favorite movies list.

All movies information came from The Movie Database website (https://www.themoviedb.org/). They have this amazing API (https://developers.themoviedb.org/3/getting-started/introduction) that could be used by any one.
