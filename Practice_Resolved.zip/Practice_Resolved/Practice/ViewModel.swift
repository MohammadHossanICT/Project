//
//  ViewModel.swift
//  Practice
//
//  Created by Christian Quicano on 2/7/22.
//

import Foundation
import Combine

class ViewModel {
    
    @Published var data = Data()
    
    func downloadImage(width: Int, height: Int) {
        let url = "https://picsum.photos/\(width)/\(height)"
        
        guard let urlRequest = URL(string: url) else { return }
        
        URLSession.shared.dataTask(with: urlRequest) { [weak self] data, response, error in
            if let data = data {
                self?.data = data
            }
        }
        .resume()
    }
    
}
