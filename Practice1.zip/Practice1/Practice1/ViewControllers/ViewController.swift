//
//  ViewController.swift
//  Practice1
//
//  Created by Consultant on 2/7/22.
//

import UIKit

class ViewController: UIViewController {
    private lazy var picChanger: UIImageView = {
        let picChanger = UIImageView()
        picChanger.contentMode = .scaleAspectFit
        picChanger.translatesAutoresizingMaskIntoConstraints = false
        return picChanger
    }()
    private lazy var btnSwap: UIButton = {
        let btnSwap = UIButton()
        btnSwap.translatesAutoresizingMaskIntoConstraints = false
        btnSwap.setTitle("Load a new image", for: .normal)
        btnSwap.setTitleColor(.blue, for: .normal)
        btnSwap.addTarget(self, action: #selector(tapButton), for: .touchUpInside)
        return btnSwap
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpUI()
        // Do any additional setup after loading the view.
        
    }
    @objc private func tapButton() {
        guard let imageData = try? Data(contentsOf: URL(string: NetworkURLs.baseURL)!) else{
            return
        }
        picChanger.image = UIImage(data: imageData)
        
    }
    private func setUpUI(){
        view.backgroundColor = .white
        view.addSubview(picChanger)
        view.addSubview(btnSwap)
        let safeArea = view.safeAreaLayoutGuide
        picChanger.topAnchor.constraint(equalTo: safeArea.topAnchor).isActive = true
        picChanger.leadingAnchor.constraint(equalTo: safeArea.leadingAnchor).isActive = true
        picChanger.trailingAnchor.constraint(equalTo: safeArea.trailingAnchor).isActive = true
        picChanger.bottomAnchor.constraint(equalTo: safeArea.bottomAnchor).isActive = true
        
        btnSwap.heightAnchor.constraint(equalToConstant: 20).isActive = true
        btnSwap.trailingAnchor.constraint(equalTo: safeArea.trailingAnchor).isActive = true
        btnSwap.leadingAnchor.constraint(equalTo: safeArea.leadingAnchor).isActive = true
        btnSwap.bottomAnchor.constraint(equalTo: safeArea.bottomAnchor).isActive = true
    }

}

