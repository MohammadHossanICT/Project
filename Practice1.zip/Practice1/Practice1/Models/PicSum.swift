//
//  PicSum.swift
//  Practice1
//
//  Created by Consultant on 2/7/22.
//

import Foundation

struct PicSum: Codable {
    
    
}
