//
//  NetworkURLs.swift
//  Practice1
//
//  Created by Consultant on 2/7/22.
//

import Foundation
import UIKit

enum NetworkURLs{
    static let baseURL = "https://picsum.photos/500/500"
}
