//
//  NetworkManager.swift
//  Practice1
//
//  Created by Consultant on 2/7/22.
//

import Foundation

class NetworkManager{
//could not succesfully find a way to parse this api into the model used manual change instead. If it was an api i feel like we could but we are just fetching it from a source
}

